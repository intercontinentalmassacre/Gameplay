/*
 * framegen.h — standalone Vulkan frame generator (original implementation).
 *
 * This is NOT a wrapper around Lossless Scaling and contains no code or
 * shaders from Lossless.dll / lsfg-vk.  The pass structure (pyramid, optical
 * flow, warp, occlusion, blend, UI mask) is an independent implementation.
 *
 * Target: Vulkan 1.1+, Android / Linux / Windows.
 * The caller owns the VkDevice and VkQueue; the library records commands into
 * a caller-provided VkCommandBuffer, so it can be integrated into an emulator
 * render loop without a second device.
 */
#ifndef FRAMEGEN_H
#define FRAMEGEN_H

#include <stdint.h>
#include <vulkan/vulkan.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FG_VERSION_MAJOR 0
#define FG_VERSION_MINOR 1
#define FG_VERSION_PATCH 0

#ifndef FG_API
#define FG_API
#endif

typedef struct fg_context fg_context;

typedef enum fg_result {
    FG_OK = 0,
    FG_E_INVALID = -1,
    FG_E_UNSUPPORTED = -2,
    FG_E_OUT_OF_MEMORY = -3,
    FG_E_VULKAN = -4,
    FG_E_IO = -5,
    FG_E_BUSY = -6
} fg_result;

/*
 * Use one Vulkan 1.1+ device with a compute-capable queue; `queue_family` is
 * its family. Enable shaderStorageImageExtendedFormats
 * when creating the device: physical support alone is not sufficient.
 *
 * `shader_dir` points to a directory containing the compiled .spv files:
 *   luma_downsample.spv, flow_init.spv, flow_refine.spv,
 *   ui_mask.spv, motion_to_flow.spv and the matching warp_blend variant.
 *   multi_hypothesis also requires flow_confidence.spv. Rebuild callers
 *   and shaders together when changing the public descriptor layout.
 * On Android, copy the SPIR-V files from assets to a real directory at first
 * launch, or set shader_dir to a path inside the app's files dir.
 */
typedef struct fg_desc {
    VkInstance       instance;
    VkPhysicalDevice physical_device;
    VkDevice         device;
    VkQueue          queue;
    uint32_t         queue_family;

    /* Optional: if VK_NULL_HANDLE, the library creates its own. */
    VkCommandPool    command_pool;

    /* Format of the color images the caller supplies. */
    VkFormat         color_format;      /* RGBA8_UNORM or RGBA16_SFLOAT */

    uint32_t         width;
    uint32_t         height;

    /*
     * 0.25..1.0.  The finest flow/luma level is at this fraction of the
     * output size; 0 selects 0.5.
     */
    float            flow_scale;

    /*
     * 0 = quality (3-level flow, 5 LK iterations, bicubic color)
     * 1 = balanced (3-level flow, 3 LK iterations, bilinear color)
     * 2 = performance (3-level pyramid, skip coarsest LK, 1 iteration at finer levels)
     */
    int              quality;

    /* If true and prev.motion is provided, use the caller's motion vectors
     * instead of estimating optical flow.  The motion image is full-res
     * RG16F/RG32F in pixels (prev -> curr).  Backward flow is approximated as
     * the negative of the forward field. */
    int              use_motion_vectors;

    /* Reserved: depth-assisted disocclusion.  Not implemented in 0.1. */
    int              use_depth;

    const char*      shader_dir;
    int              disable_ui_mask;
    int              multi_hypothesis; /* independent candidates + cached confidence; optical flow only */
} fg_desc;

/* A caller-owned image plus its view. */
typedef struct fg_image {
    VkImage       image;
    VkImageView   view;
    VkImageLayout layout;
    VkFormat      format;
} fg_image;

/* A frame.  motion/depth may be zero-initialised (image = VK_NULL_HANDLE). */
typedef struct fg_frame {
    fg_image color;
    fg_image motion;    /* optional RG16F/RG32F, full-res pixels */
    fg_image depth;     /* optional R32F, full-res */
} fg_frame;

/*
 * Create/destroy.  The library does not take ownership of instance/device/
 * queue; it only creates its own pipelines, images, descriptor sets and (if
 * needed) a command pool.  `fg_destroy` does not destroy the caller's objects.
 */
FG_API int  fg_create(const fg_desc* desc, fg_context** out);
FG_API void fg_destroy(fg_context* ctx);
FG_API int  fg_resize(fg_context* ctx, uint32_t width, uint32_t height);

/*
 * Record one intermediate frame at time t in [0,1] into `cmd`.
 * Record outside rendering. Caller owns layout transitions, visibility and
 * queue ownership. All used images must already be in GENERAL; input colors
 * and outputs must match desc.color_format and context extent. Inputs require
 * SAMPLED, outputs require STORAGE, no output may alias any input/other output.
 * Motion, when provided, requires SAMPLED RG16F/RG32F at the same extent.
 * Insert a COMPUTE_SHADER/SHADER_WRITE dependency before consuming output.
 * Context and its queue/pool must be externally synchronized.
 */
FG_API int  fg_record(fg_context* ctx, VkCommandBuffer cmd,
                      const fg_frame* prev, const fg_frame* curr,
                      float t, fg_image* out);

#define FG_MAX_OUTPUTS 5

/* One preparation, 1..FG_MAX_OUTPUTS outputs, times strictly increasing in [0,1].
 * Older is optional: supplies the third color frame for the UI heuristic.
 * Only one batch may occupy a context. Use separate contexts for overlap.
 */
FG_API int fg_record_batch(fg_context* ctx, VkCommandBuffer cmd,
                           const fg_frame* older, const fg_frame* prev, const fg_frame* curr,
                           uint32_t count, const float* times, const fg_image* outputs);

/* Call after GPU completion or after resetting/discarding the unsubmitted
 * command buffer. Do not submit that command buffer again after recycling.
 * Complete outstanding work before fg_destroy as well.
 */
FG_API void fg_recycle(fg_context* ctx);

/* Debug: after fg_record, copy the coarse-level flow of the last pair into dst at offset
 * (forward RGBA32F, then backward RGBA32F). Reports the flow extent in *out_w/*out_h. */
FG_API int fg_debug_copy_flow(fg_context* ctx, VkCommandBuffer cmd, VkBuffer dst,
                              VkDeviceSize offset, uint32_t* out_w, uint32_t* out_h);

/*
 * Convenience path: allocates a command buffer, records, submits to the
 * context queue and waits on a fence.  Not suitable for a render loop; use
 * fg_record there.
 */
FG_API int  fg_generate(fg_context* ctx,
                        const fg_frame* prev, const fg_frame* curr,
                        float t, fg_image* out);

FG_API const char* fg_last_error(const fg_context* ctx);
FG_API const char* fg_version_string(void);

#ifdef __cplusplus
}
#endif

#endif /* FRAMEGEN_H */
